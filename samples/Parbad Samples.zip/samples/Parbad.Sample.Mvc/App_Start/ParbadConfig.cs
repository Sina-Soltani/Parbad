﻿using Microsoft.EntityFrameworkCore;
using Parbad.Builder;

namespace Parbad.Sample.Mvc
{
    public static class ParbadConfig
    {
        public static IParbadBuilder Configure()
        {
            return
                ParbadBuilder.CreateDefaultBuilder()
                    .ConfigureGateways(gateways =>
                {
                    gateways
                        .AddParbadVirtual()
                        .WithOptions(options => options.GatewayPath = "/MyVirtualGateway");
                })
                .ConfigureHttpContext(builder => builder.UseOwinFromCurrentHttpContext())
                .ConfigureDatabase(builder =>
                {
                    // EF CORE In-Memory (For testing and development only)
                    builder.UseInMemoryDatabase("MyDatabase");
                })
                .ConfigureDatabaseInitializer(builder =>
                {
                    // For creating
                    builder.CreateDatabase();
                });
        }
    }
}
