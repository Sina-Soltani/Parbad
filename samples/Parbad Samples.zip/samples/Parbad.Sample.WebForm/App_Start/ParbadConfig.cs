﻿using Microsoft.EntityFrameworkCore;
using Parbad.Builder;

namespace Parbad.Sample.WebForm
{
    public static class ParbadConfig
    {
        public static IOnlinePaymentAccessor Configure()
        {
            return
                ParbadBuilder.CreateDefaultBuilder()
                    .ConfigureGateways(gateways =>
                {
                    gateways
                        .AddParbadVirtual()
                        .WithOptions(options => options.GatewayPath = "/MyVirtualGateway");
                })
                .ConfigureHttpContext(builder => builder.UseOwinFromCurrentHttpContext())
                .ConfigureDatabase(builder =>
                {
                    // EF CORE In-Memory (For testing and development only)
                    builder.UseInMemoryDatabase("MyDatabase");
                })
                .ConfigureDatabaseInitializer(builder =>
                {
                    // For creating
                    builder.CreateDatabase();
                })
                .Build(); // don't forget to use the build method. Otherwise you cannot use the StaticOnlinePayment class.
        }
    }
}
