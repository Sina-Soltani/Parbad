﻿using System.Web.Mvc;

namespace Parbad.Sample.Mvc.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
