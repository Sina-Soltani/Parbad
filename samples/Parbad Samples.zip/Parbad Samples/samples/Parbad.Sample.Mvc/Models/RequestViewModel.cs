﻿namespace Parbad.Sample.Mvc.Models
{
    public class RequestViewModel
    {
        public long Amount { get; set; }

        public Gateway Gateway { get; set; }
    }
}
