﻿namespace Parbad.Sample.WebForms.Models
{
    public enum Gateways
    {
        Saman,
        Mellat,
        Parsian,
        Pasargad,
        IranKish,
        Melli,
        AsanPardakht,
        ParbadVirtual
    }
}
